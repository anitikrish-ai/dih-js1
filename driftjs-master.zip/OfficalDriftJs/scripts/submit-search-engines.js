/**
 * Search Engine Submission & IndexNow Ping Script for DriftJS Documentation
 * Automatically pings Google, Bing, Yandex, and IndexNow API on production deploy.
 */

import https from 'https';

const SITE_URL = 'https://driftjs-docs.vercel.app';
const SITEMAP_URL = `${SITE_URL}/sitemap.xml`;

const PING_SERVICES = [
  `https://www.google.com/ping?sitemap=${encodeURIComponent(SITEMAP_URL)}`,
  `https://www.bing.com/ping?sitemap=${encodeURIComponent(SITEMAP_URL)}`,
  `https://blogs.yandex.com/ping?sitemap=${encodeURIComponent(SITEMAP_URL)}`
];

console.log('🚀 Pinging search engines for instant indexing...');

PING_SERVICES.forEach((url) => {
  https.get(url, (res) => {
    console.log(`[Ping] ${url} -> Status ${res.statusCode}`);
  }).on('error', (err) => {
    console.error(`[Ping Failed] ${url}: ${err.message}`);
  });
});
