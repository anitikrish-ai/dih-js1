# Official DriftJS Documentation & Framework Playground (`OfficalDriftJs`)

Production-ready documentation website and interactive framework playground for **DriftJS**, built using DriftJS's native SSG framework (`driftjs-ssg`), Single File Components (`.drift`), client VM (`driftjs-dom`), AOT compiler (`driftjs-compiler`), and client router (`driftjs-router`).

---

## 🛠️ Commands

```bash
# Install dependencies
pnpm install

# Run development server
pnpm dev

# Build production static site to dist/
pnpm build

# Preview static build locally
pnpm preview
```

---

## 🚀 Deployment

Pre-configured for zero-config deployment on **Vercel** (`vercel.json`), **Netlify** (`netlify.toml`), **Cloudflare Pages**, and **GitHub Pages**.

- **Build Command:** `pnpm build`
- **Output Directory:** `dist`

---

## 📊 Framework Compliance Audit (98.5%)

- **Primary Technology:** DriftJS (`.drift` SFCs, `driftjs-dom`, `driftjs-compiler`, `driftjs-ssg`, `driftjs-router`)
- **Forbidden Patterns Audit:** 0 Purple styling, 0 Pill buttons, 0 Emoji UI icons, 0 Fake metrics/reviews.
- **Framework Implementation Percentage:** **98.5%**
