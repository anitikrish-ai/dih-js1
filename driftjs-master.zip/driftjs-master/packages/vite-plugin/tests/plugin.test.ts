import { describe, it, expect, vi } from 'vitest';
import { driftPlugin, serializeValueToJS, serializeConstants } from '../src/index.js';
import type { Plugin } from 'vite';

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function makePlugin(opts = {}): Plugin {
  return driftPlugin(opts) as Plugin;
}

/**
 * Calls the plugin's `transform` hook with a `.drift` source string.
 * Returns the generated code string, or null if the plugin skipped the file.
 */
function transform(plugin: Plugin, src: string, id = 'test.drift'): string | null {
  const hook = plugin.transform as (src: string, id: string) => { code: string; map: null } | null;
  const result = hook.call({ error: (msg: string) => { throw new Error(msg); } } as any, src, id);
  return result?.code ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

describe('driftPlugin – identity', () => {
  it('ignores non-.drift files', () => {
    const plugin = makePlugin();
    const result = transform(plugin, '<div>hello</div>', 'app.ts');
    expect(result).toBeNull();
  });

  it('transforms .drift files', () => {
    const plugin = makePlugin();
    const code = transform(plugin, '<p>Hello</p>');
    expect(code).not.toBeNull();
  });
});

describe('driftPlugin – emitted ESM structure', () => {
  it('exports default compiledModule', () => {
    const plugin = makePlugin();
    const code = transform(plugin, '<h1>Drift</h1>')!;

    expect(code).toContain('const compiledModule =');
    expect(code).toContain('export default compiledModule;');
  });

  it('includes the source file path in a comment', () => {
    const plugin = makePlugin();
    const code = transform(plugin, '<div/>', '/project/hero.drift')!;
    expect(code).toContain('hero.drift');
  });

  it('compiledModule has bytecode and constants arrays', () => {
    const plugin = makePlugin();
    const code = transform(plugin, '<div>test</div>')!;
    expect(code).toMatch(/bytecode:\s*(new Uint32Array\(|\[)/);
    expect(code).toMatch(/constants:\s*\[/);
  });
});

describe('driftPlugin – compilation correctness', () => {
  it('compiles a static element without throwing', () => {
    const plugin = makePlugin();
    expect(() => transform(plugin, '<section class="hero"><h1>Title</h1></section>')).not.toThrow();
  });

  it('compiles @if / @else directives', () => {
    const plugin = makePlugin();
    const src = '@if show { <p>Visible</p> } @else { <p>Hidden</p> }';
    expect(() => transform(plugin, src)).not.toThrow();
  });

  it('compiles @for loops', () => {
    const plugin = makePlugin();
    const src = '<ul>@for item in items { <li>{item}</li> }</ul>';
    expect(() => transform(plugin, src)).not.toThrow();
  });

  it('compiles interpolations', () => {
    const plugin = makePlugin();
    const src = '<p>{greeting}, {name}!</p>';
    expect(() => transform(plugin, src)).not.toThrow();
  });

  it('surfaces DriftJS compilation errors as Vite build errors', () => {
    const plugin = makePlugin();
    // Unclosed tag — should throw via this.error()
    expect(() => transform(plugin, '<div>')).toThrow(/DriftJS.*Compilation failed/i);
  });

  it('correctly handles namespace imports and side-effect imports', () => {
    const plugin = makePlugin();
    const src = `
      <script>
        import * as utils from "./utils";
        import "./style.css";
        import Button from "./Button.drift";
      </script>
      <div><Button /></div>
    `;
    const code = transform(plugin, src)!;

    expect(code).toContain('import * as utils from "./utils";');
    expect(code).toContain('import "./style.css";');
    expect(code).toContain('import Button from "./Button.drift";');
    expect(code).toContain('utils,');
    expect(code).toContain('Button');
  });
});

describe('driftPlugin – debug option', () => {
  it('calls console.log when debug: true', () => {
    const spy = vi.spyOn(console, 'log').mockImplementation(() => {});
    const plugin = makePlugin({ debug: true });
    transform(plugin, '<p>Debug</p>');
    expect(spy).toHaveBeenCalled();
    spy.mockRestore();
  });

  it('does not call console.log when debug: false (default)', () => {
    const spy = vi.spyOn(console, 'log').mockImplementation(() => {});
    const plugin = makePlugin();
    transform(plugin, '<p>Quiet</p>');
    expect(spy).not.toHaveBeenCalled();
    spy.mockRestore();
  });
});

describe('driftPlugin – HMR', () => {
  it('triggers a full-reload for .drift files', () => {
    const plugin = makePlugin();
    const send = vi.fn();
    const invalidateModule = vi.fn();
    const fakeModule = { id: '/project/hero.drift' };

    const ctx = {
      file: '/project/hero.drift',
      server: {
        moduleGraph: {
          getModuleById: vi.fn().mockReturnValue(fakeModule),
          invalidateModule,
        },
        ws: { send },
      },
    };

    const hook = plugin.handleHotUpdate as (arg: any) => void;
    hook(ctx as any);

    expect(invalidateModule).toHaveBeenCalledWith(fakeModule);
    expect(send).toHaveBeenCalledWith({ type: 'full-reload', path: '*' });
  });

  it('ignores non-.drift files in HMR', () => {
    const plugin = makePlugin();
    const send = vi.fn();

    const ctx = {
      file: '/project/app.ts',
      server: { moduleGraph: { getModuleById: vi.fn() }, ws: { send } },
    };

    const hook = plugin.handleHotUpdate as (arg: any) => void;
    hook(ctx as any);
    expect(send).not.toHaveBeenCalled();
  });

  it('serializes NaN, Infinity, -Infinity, and negative zero as valid JS literals rather than null', () => {
    expect(serializeValueToJS(NaN)).toBe('NaN');
    expect(serializeValueToJS(Infinity)).toBe('Infinity');
    expect(serializeValueToJS(-Infinity)).toBe('-Infinity');
    expect(serializeValueToJS(-0)).toBe('-0');
    expect(serializeValueToJS(123n)).toBe('123n');

    const serialized = serializeConstants([NaN, Infinity, -Infinity, -0, 'text']);
    expect(serialized).toContain('NaN');
    expect(serialized).toContain('Infinity');
    expect(serialized).toContain('-Infinity');
    expect(serialized).toContain('-0');
    expect(serialized).not.toContain('null');
  });

  it('serializes RegExp, Date, Set, Map, and TypedArrays correctly (BUG-003)', () => {
    expect(serializeValueToJS(/^[a-z]+$/gi)).toBe('/^[a-z]+$/gi');
    const date = new Date(1700000000000);
    expect(serializeValueToJS(date)).toBe('new Date(1700000000000)');
    const set = new Set([1, 2, 'three']);
    expect(serializeValueToJS(set)).toBe('new Set([1, 2, "three"])');
    const map = new Map([['key', 42]]);
    expect(serializeValueToJS(map)).toBe('new Map([["key", 42]])');
    const uint8 = new Uint8Array([10, 20, 30]);
    expect(serializeValueToJS(uint8)).toBe('new Uint8Array([10, 20, 30])');
  });

  it('serializes derived reactive bindings in compiledModule', () => {
    const plugin = makePlugin();
    const sfc = `
      <script>
        let count = 1;
        let double = derive(count * 2);
      </script>
      <div>{double}</div>
    `;
    const code = transform(plugin, sfc)!;
    expect(code).toContain('derived: [{"name":"double","deps":["count"],"exprIdx":');
  });

  it('serializes effect bindings in compiledModule', () => {
    const plugin = makePlugin();
    const sfc = `
      <script>
        let count = 1;
        effect(() => {
          console.log(count);
        });
      </script>
      <div>{count}</div>
    `;
    const code = transform(plugin, sfc)!;
    expect(code).toContain('effects: [{"deps":["count"],"exprIdx":');
  });
});
