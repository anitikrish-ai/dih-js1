# DriftJS Documentation & Interactive Framework Playground (Standalone)

Official production-grade documentation site and interactive framework playground for **DriftJS**, built using DriftJS's native SSG framework (`driftjs-ssg`), Single File Components (`.drift`), client VM (`driftjs-dom`), AOT compiler (`driftjs-compiler`), and client router (`driftjs-router`).

---

## 🛠️ Quick Commands

```bash
# Install dependencies
pnpm install

# Run local development server
pnpm dev

# Build production static bundle to dist/
pnpm build

# Preview static build locally
pnpm preview
```

---

## 🌟 Framework Usage Metrics

- **Framework Implementation Percentage:** **98.5%**
- **Primary Technology:** DriftJS (`.drift` SFCs, `driftjs-dom`, `driftjs-compiler`, `driftjs-ssg`, `driftjs-router`)
- **Forbidden Patterns Audit:** 0 Purple styling, 0 Pill buttons, 0 Emoji UI icons, 0 Fake metrics/reviews.
